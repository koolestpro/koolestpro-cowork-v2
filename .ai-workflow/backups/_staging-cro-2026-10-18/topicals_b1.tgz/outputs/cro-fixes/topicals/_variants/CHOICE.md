# Topicals homepage hero: 4 directions, 2026-10-18

All four use the same real assets, copy and facts. Board: `../koolestpro_topicals_homepage-hero_variants-board.png` (neutral, posts on X first).

- **A, Range, labelled (CHOSEN).** Five real packshots on a blush field, each labelled with the flare-up it treats. Topicals is organised by skin condition, so the hero answers "is this for my skin?" before any reading. Centered short stack, one CTA.
- **B, Face photo first (runner-up, A/B challenger).** Their own eye-mask portrait with two labels. Most on-brand mood, but it narrows the homepage to one kit (the same problem the live hero has).
- **C, Full-bleed product.** Dark Spot Kit photo with a dark scrim and the stack over it. Strong, but one product again, and the dark red scrim fights the red CTA.
- **D, Headline first.** Text band then a 2x2 concern grid. Clearest, least visual; the products shrink to thumbnails.

Why A: the #1 finding is that screen one never says what Topicals treats. A is the only direction where the image itself says it.
